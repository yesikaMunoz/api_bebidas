//request, needle 
const axios =require('axios');

// definir la url de la api
const url = `https://dog.ceo/api/breeds/list/all`

// ejecutar transaccion asyncrona
axios.get (url)
    .then( (respuesta) =>{
        console.log(respuesta.message.results)
    })
    .catch((error)=>{
        console.log(error)
    })
    