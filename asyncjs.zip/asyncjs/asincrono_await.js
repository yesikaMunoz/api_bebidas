const axios = require('axios')
const url=`https://api.sampleapis.com/coffee/hot`

const cafe =async () => {
const response = await axios.get(url)

let arreglo = response.data
    arreglo.forEach((late) => {
        console.log(late)
        console.log("--------")
    })
}

cafe()