//request, needle 
const request =require('request');

// definir la url de la api
const url = `https://dog.ceo/api/breeds/list/all`

//hacer una peticion(request)
// a la api de rick & morty
// utilizando request
let r =request(url, 
              {json:true} , 
              (err, res, body) => {
                let perritos = body.results
                perritos.forEach((razas) => {
                 console.log(razas)
                 console.log ("------------")   
                })
              })